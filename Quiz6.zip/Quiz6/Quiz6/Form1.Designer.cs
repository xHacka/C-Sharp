﻿namespace Quiz6 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.static1InputWidth = new System.Windows.Forms.TextBox();
            this.static1InputHeight = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.static1Btn = new System.Windows.Forms.Button();
            this.static1Output = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.static2InputNumbers = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.static2CalcBtn = new System.Windows.Forms.Button();
            this.static2Output = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.static3Output1 = new System.Windows.Forms.Label();
            this.static3Output2 = new System.Windows.Forms.Label();
            this.static3CalcBtn = new System.Windows.Forms.Button();
            this.static3Output3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.getterSetters1Input = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.getterSetters1Btn = new System.Windows.Forms.Button();
            this.getterSetters1Output = new System.Windows.Forms.Label();
            this.getterSetters2Btn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.getterSetters2Input = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.getterSetters2Output = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.getterSetters3Output = new System.Windows.Forms.Label();
            this.getterSetters3Btn = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.getterSetters3Input = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.indexer1Output = new System.Windows.Forms.Label();
            this.indexer1Btn = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.indexer1Input = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.indexer1NextBtn = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "სტატიკური კომპონენტები. static მოდიფიკატორი ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "1";
            // 
            // static1InputWidth
            // 
            this.static1InputWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static1InputWidth.Location = new System.Drawing.Point(83, 53);
            this.static1InputWidth.Name = "static1InputWidth";
            this.static1InputWidth.Size = new System.Drawing.Size(75, 22);
            this.static1InputWidth.TabIndex = 2;
            // 
            // static1InputHeight
            // 
            this.static1InputHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static1InputHeight.Location = new System.Drawing.Point(83, 79);
            this.static1InputHeight.Name = "static1InputHeight";
            this.static1InputHeight.Size = new System.Drawing.Size(75, 22);
            this.static1InputHeight.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Width";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Height";
            // 
            // static1Btn
            // 
            this.static1Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static1Btn.Location = new System.Drawing.Point(43, 135);
            this.static1Btn.Name = "static1Btn";
            this.static1Btn.Size = new System.Drawing.Size(115, 46);
            this.static1Btn.TabIndex = 5;
            this.static1Btn.Text = "Caclulate Perimeter";
            this.static1Btn.UseVisualStyleBackColor = true;
            this.static1Btn.Click += new System.EventHandler(this.static1Btn_Click);
            // 
            // static1Output
            // 
            this.static1Output.AutoSize = true;
            this.static1Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static1Output.Location = new System.Drawing.Point(30, 106);
            this.static1Output.Name = "static1Output";
            this.static1Output.Size = new System.Drawing.Size(0, 16);
            this.static1Output.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(207, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "2";
            // 
            // static2InputNumbers
            // 
            this.static2InputNumbers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static2InputNumbers.Location = new System.Drawing.Point(232, 75);
            this.static2InputNumbers.Name = "static2InputNumbers";
            this.static2InputNumbers.Size = new System.Drawing.Size(176, 22);
            this.static2InputNumbers.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(231, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(257, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Enter Numbers Seperated By Space";
            // 
            // static2CalcBtn
            // 
            this.static2CalcBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static2CalcBtn.Location = new System.Drawing.Point(232, 147);
            this.static2CalcBtn.Name = "static2CalcBtn";
            this.static2CalcBtn.Size = new System.Drawing.Size(176, 23);
            this.static2CalcBtn.TabIndex = 10;
            this.static2CalcBtn.Text = "Caclulate Sum Of Odds";
            this.static2CalcBtn.UseVisualStyleBackColor = true;
            this.static2CalcBtn.Click += new System.EventHandler(this.static2CalcBtn_Click);
            // 
            // static2Output
            // 
            this.static2Output.AutoSize = true;
            this.static2Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static2Output.Location = new System.Drawing.Point(231, 105);
            this.static2Output.Name = "static2Output";
            this.static2Output.Size = new System.Drawing.Size(0, 16);
            this.static2Output.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(532, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "3";
            // 
            // static3Output1
            // 
            this.static3Output1.AutoSize = true;
            this.static3Output1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static3Output1.Location = new System.Drawing.Point(545, 62);
            this.static3Output1.Name = "static3Output1";
            this.static3Output1.Size = new System.Drawing.Size(60, 16);
            this.static3Output1.TabIndex = 13;
            this.static3Output1.Text = "Array 1:";
            // 
            // static3Output2
            // 
            this.static3Output2.AutoSize = true;
            this.static3Output2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static3Output2.Location = new System.Drawing.Point(545, 82);
            this.static3Output2.Name = "static3Output2";
            this.static3Output2.Size = new System.Drawing.Size(60, 16);
            this.static3Output2.TabIndex = 13;
            this.static3Output2.Text = "Array 2:";
            // 
            // static3CalcBtn
            // 
            this.static3CalcBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static3CalcBtn.Location = new System.Drawing.Point(548, 124);
            this.static3CalcBtn.Name = "static3CalcBtn";
            this.static3CalcBtn.Size = new System.Drawing.Size(147, 35);
            this.static3CalcBtn.TabIndex = 14;
            this.static3CalcBtn.Text = "Count Odd Numbers From Random 2D Array";
            this.static3CalcBtn.UseVisualStyleBackColor = true;
            this.static3CalcBtn.Click += new System.EventHandler(this.static3CalcBtn_Click);
            // 
            // static3Output3
            // 
            this.static3Output3.AutoSize = true;
            this.static3Output3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static3Output3.Location = new System.Drawing.Point(545, 105);
            this.static3Output3.Name = "static3Output3";
            this.static3Output3.Size = new System.Drawing.Size(0, 16);
            this.static3Output3.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Getter/Setters";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(11, 262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "1";
            // 
            // getterSetters1Input
            // 
            this.getterSetters1Input.Location = new System.Drawing.Point(57, 286);
            this.getterSetters1Input.Name = "getterSetters1Input";
            this.getterSetters1Input.Size = new System.Drawing.Size(56, 20);
            this.getterSetters1Input.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 289);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Number";
            // 
            // getterSetters1Btn
            // 
            this.getterSetters1Btn.Location = new System.Drawing.Point(57, 331);
            this.getterSetters1Btn.Name = "getterSetters1Btn";
            this.getterSetters1Btn.Size = new System.Drawing.Size(75, 36);
            this.getterSetters1Btn.TabIndex = 18;
            this.getterSetters1Btn.Text = "Update Number";
            this.getterSetters1Btn.UseVisualStyleBackColor = true;
            this.getterSetters1Btn.Click += new System.EventHandler(this.getterSetters1Btn_Click);
            // 
            // getterSetters1Output
            // 
            this.getterSetters1Output.AutoSize = true;
            this.getterSetters1Output.Location = new System.Drawing.Point(7, 312);
            this.getterSetters1Output.Name = "getterSetters1Output";
            this.getterSetters1Output.Size = new System.Drawing.Size(0, 13);
            this.getterSetters1Output.TabIndex = 17;
            // 
            // getterSetters2Btn
            // 
            this.getterSetters2Btn.Location = new System.Drawing.Point(250, 331);
            this.getterSetters2Btn.Name = "getterSetters2Btn";
            this.getterSetters2Btn.Size = new System.Drawing.Size(75, 36);
            this.getterSetters2Btn.TabIndex = 22;
            this.getterSetters2Btn.Text = "Update Number";
            this.getterSetters2Btn.UseVisualStyleBackColor = true;
            this.getterSetters2Btn.Click += new System.EventHandler(this.getterSetters2Btn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(200, 289);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Number";
            // 
            // getterSetters2Input
            // 
            this.getterSetters2Input.Location = new System.Drawing.Point(250, 286);
            this.getterSetters2Input.Name = "getterSetters2Input";
            this.getterSetters2Input.Size = new System.Drawing.Size(56, 20);
            this.getterSetters2Input.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(204, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 16);
            this.label12.TabIndex = 19;
            this.label12.Text = "2";
            // 
            // getterSetters2Output
            // 
            this.getterSetters2Output.AutoSize = true;
            this.getterSetters2Output.Location = new System.Drawing.Point(202, 311);
            this.getterSetters2Output.Name = "getterSetters2Output";
            this.getterSetters2Output.Size = new System.Drawing.Size(0, 13);
            this.getterSetters2Output.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 265);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Only Positive Numbers";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label14.Location = new System.Drawing.Point(221, 264);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Only Odd Numbers";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label15.Location = new System.Drawing.Point(419, 265);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "Only Multiples Of 5";
            // 
            // getterSetters3Output
            // 
            this.getterSetters3Output.AutoSize = true;
            this.getterSetters3Output.Location = new System.Drawing.Point(397, 311);
            this.getterSetters3Output.Name = "getterSetters3Output";
            this.getterSetters3Output.Size = new System.Drawing.Size(0, 13);
            this.getterSetters3Output.TabIndex = 29;
            // 
            // getterSetters3Btn
            // 
            this.getterSetters3Btn.Location = new System.Drawing.Point(445, 331);
            this.getterSetters3Btn.Name = "getterSetters3Btn";
            this.getterSetters3Btn.Size = new System.Drawing.Size(75, 36);
            this.getterSetters3Btn.TabIndex = 28;
            this.getterSetters3Btn.Text = "Update Number";
            this.getterSetters3Btn.UseVisualStyleBackColor = true;
            this.getterSetters3Btn.Click += new System.EventHandler(this.getterSetters3Btn_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(395, 289);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 27;
            this.label17.Text = "Number";
            // 
            // getterSetters3Input
            // 
            this.getterSetters3Input.Location = new System.Drawing.Point(445, 286);
            this.getterSetters3Input.Name = "getterSetters3Input";
            this.getterSetters3Input.Size = new System.Drawing.Size(56, 20);
            this.getterSetters3Input.TabIndex = 26;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(399, 262);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 16);
            this.label18.TabIndex = 25;
            this.label18.Text = "3";
            // 
            // indexer1Output
            // 
            this.indexer1Output.AutoSize = true;
            this.indexer1Output.Location = new System.Drawing.Point(666, 366);
            this.indexer1Output.Name = "indexer1Output";
            this.indexer1Output.Size = new System.Drawing.Size(0, 13);
            this.indexer1Output.TabIndex = 35;
            // 
            // indexer1Btn
            // 
            this.indexer1Btn.Location = new System.Drawing.Point(663, 386);
            this.indexer1Btn.Name = "indexer1Btn";
            this.indexer1Btn.Size = new System.Drawing.Size(129, 36);
            this.indexer1Btn.TabIndex = 34;
            this.indexer1Btn.Text = "Create Indexer From Input";
            this.indexer1Btn.UseVisualStyleBackColor = true;
            this.indexer1Btn.Click += new System.EventHandler(this.indexer1Btn_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(613, 365);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 13);
            this.label20.TabIndex = 33;
            this.label20.Text = "Output ->";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(618, 269);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 16);
            this.label21.TabIndex = 31;
            this.label21.Text = "4";
            // 
            // indexer1Input
            // 
            this.indexer1Input.Location = new System.Drawing.Point(663, 333);
            this.indexer1Input.Name = "indexer1Input";
            this.indexer1Input.Size = new System.Drawing.Size(129, 20);
            this.indexer1Input.TabIndex = 16;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(636, 272);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 13);
            this.label23.TabIndex = 24;
            this.label23.Text = "Only Positive Numbers";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(614, 293);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(151, 36);
            this.label16.TabIndex = 24;
            this.label16.Text = "Enter Numbers Seperated By Space (Length 5!)";
            // 
            // indexer1NextBtn
            // 
            this.indexer1NextBtn.Location = new System.Drawing.Point(663, 433);
            this.indexer1NextBtn.Name = "indexer1NextBtn";
            this.indexer1NextBtn.Size = new System.Drawing.Size(129, 25);
            this.indexer1NextBtn.TabIndex = 34;
            this.indexer1NextBtn.Text = "Next Number";
            this.indexer1NextBtn.UseVisualStyleBackColor = true;
            this.indexer1NextBtn.Click += new System.EventHandler(this.indexer1NextBtn_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(619, 238);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 16);
            this.label19.TabIndex = 0;
            this.label19.Text = "Indexer";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(833, 508);
            this.Controls.Add(this.indexer1Output);
            this.Controls.Add(this.indexer1NextBtn);
            this.Controls.Add(this.indexer1Btn);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.getterSetters3Output);
            this.Controls.Add(this.getterSetters3Btn);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.getterSetters3Input);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.getterSetters2Output);
            this.Controls.Add(this.getterSetters2Btn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.getterSetters2Input);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.getterSetters1Btn);
            this.Controls.Add(this.getterSetters1Output);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.indexer1Input);
            this.Controls.Add(this.getterSetters1Input);
            this.Controls.Add(this.static3Output3);
            this.Controls.Add(this.static3CalcBtn);
            this.Controls.Add(this.static3Output2);
            this.Controls.Add(this.static3Output1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.static2Output);
            this.Controls.Add(this.static2CalcBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.static2InputNumbers);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.static1Output);
            this.Controls.Add(this.static1Btn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.static1InputHeight);
            this.Controls.Add(this.static1InputWidth);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox static1InputWidth;
        private System.Windows.Forms.TextBox static1InputHeight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button static1Btn;
        private System.Windows.Forms.Label static1Output;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox static2InputNumbers;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button static2CalcBtn;
        private System.Windows.Forms.Label static2Output;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label static3Output1;
        private System.Windows.Forms.Label static3Output2;
        private System.Windows.Forms.Button static3CalcBtn;
        private System.Windows.Forms.Label static3Output3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox getterSetters1Input;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button getterSetters1Btn;
        private System.Windows.Forms.Label getterSetters1Output;
        private System.Windows.Forms.Button getterSetters2Btn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox getterSetters2Input;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label getterSetters2Output;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label getterSetters3Output;
        private System.Windows.Forms.Button getterSetters3Btn;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox getterSetters3Input;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label indexer1Output;
        private System.Windows.Forms.Button indexer1Btn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox indexer1Input;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button indexer1NextBtn;
        private System.Windows.Forms.Label label19;
    }
}

